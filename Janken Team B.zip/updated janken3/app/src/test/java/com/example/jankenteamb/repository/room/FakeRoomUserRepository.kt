package com.example.jankenteamb.repository.room

import androidx.lifecycle.MutableLiveData
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.repository.room.repository.UserRepository

class FakeRoomUserRepository: UserRepository {
    var userServiceData: LinkedHashMap<String, UserData> = LinkedHashMap()

    private val observableUser = MutableLiveData<List<UserData>>()
    private var isError = false
    private var userUid: String? = null

    override fun insertUserData(
        userData: UserData,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError){
            onError(Throwable("Error"))
        }else{
            userServiceData[userData.uid] = userData
            refreshData()
            onResult()
        }
    }

    override fun getUserPointDataByUid(onResult: (Int) -> Unit, onError: (Throwable) -> Unit) {
        if (isError){
            onError(Throwable("Error"))
        }else{
            val userData = userServiceData[userUid]
            onResult(userData?.point!!)
        }
    }

    override fun updateUserPointByUid(
        newPoint: Int,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError){
            onError(Throwable("Error"))
        }else{
            val userData = userServiceData[userUid]
            userData?.point = newPoint
            userServiceData[userUid!!] = userData!!
            refreshData()
            onResult()
        }
    }

    override fun getUserDataByUid(onResult: (UserData) -> Unit, onError: (Throwable) -> Unit) {
        if (isError){
            onError(Throwable("Error"))
        }else{
            val userData = userServiceData[userUid]
            refreshData()
            onResult(userData!!)
        }
    }

    override fun getObservableUserData(onResult: (UserData) -> Unit, onError: (Throwable) -> Unit) {
        if (isError){
            onError(Throwable("Error"))
        }else{
            val userData = userServiceData[userUid]
            refreshData()
            onResult(userData!!)
        }
    }

    override fun updateUserData(
        level: Int,
        win: Int,
        draw: Int,
        lose: Int,
        exp: Int,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        TODO("Not yet implemented")
    }

    override fun updateUserFrame(
        frameUrl: String,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        TODO("Not yet implemented")
    }

    override fun deleteUserData(userData: UserData) {
        userServiceData.remove(userData.uid)
        refreshData()
    }

    override fun onDestroy() {
        TODO("Not yet implemented")
    }

    fun addUserData(vararg users: UserData) {
        for (user in users) {
            userServiceData[user.uid] = user
        }
    }

    fun setUserUid(uid:String){
        userUid = uid
    }

    fun setError(error: Boolean){
        isError = error
    }

    fun refreshData(){
        observableUser.value = userServiceData.values.toList()
    }
}