package com.example.jankenteamb.repository.firebase

import androidx.lifecycle.MutableLiveData
import com.example.jankenteamb.model.RepositoryResult
import com.example.jankenteamb.model.firestore.GameHistoryFirestoreData
import com.example.jankenteamb.model.room.user.UserAchievementData
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.repository.firebase.repository.HistoryRepository
import com.google.firebase.firestore.QuerySnapshot
import java.lang.Exception
import java.util.LinkedHashMap

class FakeFirebaseHistoryRepository : HistoryRepository {
    var historyServiceData: LinkedHashMap<Int, GameHistoryFirestoreData> = LinkedHashMap()
    private val observableHistory = MutableLiveData<List<GameHistoryFirestoreData>>()

    private lateinit var resultState: RepositoryResult<Any>
    private val dummyError = RepositoryResult.Error(Exception("Error"))
    private val dummyCanceled = RepositoryResult.Canceled(Exception("Canceled"))

    private var historyId = 0

//    override fun addHistory(history: GameHistoryFirestoreData) {
//        historyServiceData[historyId] = history
//        historyId++
//    }

    fun addData(vararg histories: GameHistoryFirestoreData) {
        for (history in histories) {
            historyServiceData[historyId] = history
            historyId++
        }
    }

    fun setScenario(scenario: RepositoryResult<Any>) {
        resultState = scenario
    }

    fun refreshData() {
        observableHistory.value = historyServiceData.values.toList()
    }

    override suspend fun addHistory(history: GameHistoryFirestoreData): RepositoryResult<String> {
        return when (resultState) {
            is RepositoryResult.Success -> {
                historyServiceData[historyId] = history
                historyId++
                refreshData()
                RepositoryResult.Success("Add data baru berhasil")
            }
            is RepositoryResult.Error -> dummyError
            is RepositoryResult.Canceled -> dummyCanceled
        }
    }

    override suspend fun getHistoryFromFirebase(): RepositoryResult<List<GameHistoryFirestoreData>> {
        return when(resultState){
            is RepositoryResult.Success -> RepositoryResult.Success(observableHistory.value?.toList()) as RepositoryResult<List<GameHistoryFirestoreData>>
            is RepositoryResult.Error -> dummyError
            is RepositoryResult.Canceled -> dummyCanceled
        }
    }

}