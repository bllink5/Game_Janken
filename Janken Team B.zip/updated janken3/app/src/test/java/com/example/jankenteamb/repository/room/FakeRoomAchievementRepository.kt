package com.example.jankenteamb.repository.room

import androidx.lifecycle.MutableLiveData
import com.example.jankenteamb.model.room.query.JoinAchievementData
import com.example.jankenteamb.model.room.user.UserAchievementData
import com.example.jankenteamb.repository.room.repository.AchievementRepository
import kotlinx.coroutines.runBlocking

class FakeRoomAchievementRepository : AchievementRepository {
    var achievementServiceData: LinkedHashMap<Int, UserAchievementData> = LinkedHashMap()
    private lateinit var tempAchievement: JoinAchievementData
    private val observableAchievement = MutableLiveData<List<UserAchievementData>>()
    private var isError = false
    private var userUid: String? = null

    override fun insertUserAchievement(
        achievementData: UserAchievementData,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError) {
            onError(Throwable("Error"))
        } else {
            achievementServiceData[achievementData.achievementId] = achievementData
            onResult()
        }
    }

    override fun getUserAchievementProgressForRecycleView(
        onResult: (MutableList<JoinAchievementData>) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        TODO("Not yet implemented")
    }

    override fun getUserAchievementProgress(
        onResult: (MutableList<UserAchievementData>) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError) {
            onError(Throwable("Error"))
        } else {
            observableAchievement.value = achievementServiceData.values.toList()
            onResult(observableAchievement.value as MutableList<UserAchievementData>)
        }
    }

    override fun claimAchievement(
        achievementId: Int,
        onResult: (Int) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError) {
            onError(Throwable("Error"))
        } else {
            val achievement = UserAchievementData(1, achievementId, userUid!!, 0, "claimed")
            achievementServiceData[achievementId] = achievement
//            refreshData()
            onResult(achievementId)

        }

    }

    override fun updateUserAchievementByAchievementId(
        newProgress: Int,
        achievementId: Int,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        if (isError) {
            onError(Throwable("Error"))
        } else {
            val achievement =
                UserAchievementData(null, achievementId, userUid!!, newProgress, "claimed")
            achievementServiceData[achievementId] = achievement
            refreshData()
            onResult()
        }
    }

    override fun deleteUserAchievement(achievementData: UserAchievementData) {
        achievementServiceData.remove(achievementData.achievementId)
        refreshData()
    }

    override fun onDestroy() {
        TODO("Not yet implemented")
    }

    fun addAchievements(vararg achievements: UserAchievementData) {
        for (achievement in achievements) {
            achievementServiceData[achievement.achievementId] = achievement
        }
    }

    fun serError(error: Boolean){
        isError = error
    }

    fun setUserUid(uid: String) {
        userUid = uid
    }

    fun refreshData() {
        observableAchievement.value = achievementServiceData.values.toList()
    }
}