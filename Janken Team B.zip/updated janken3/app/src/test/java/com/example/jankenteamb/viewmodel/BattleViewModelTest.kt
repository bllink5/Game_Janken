package com.example.jankenteamb.viewmodel

import com.example.jankenteamb.helper.InstantRuleExecution
import com.example.jankenteamb.helper.MainCoroutineRule
import com.example.jankenteamb.helper.TrampolineSchedulerRx
import com.example.jankenteamb.helper.getOrAwaitValue
import com.example.jankenteamb.model.room.user.UserAchievementData
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.repository.firebase.FakeFirebaseAchievementRepository
import com.example.jankenteamb.repository.firebase.FakeFirebaseHistoryRepository
import com.example.jankenteamb.repository.firebase.FakeFirebaseUserRepository
import com.example.jankenteamb.repository.room.FakeRoomAchievementRepository
import com.example.jankenteamb.repository.room.FakeRoomUserRepository
import com.example.jankenteamb.utils.DispatcherProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.core.Is.`is`
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@ExperimentalCoroutinesApi
class BattleViewModelTest {
    @get:Rule
    val coroutineRule = MainCoroutineRule()

    private lateinit var roomUserRepository: FakeRoomUserRepository
    private lateinit var roomAchievementRepository: FakeRoomAchievementRepository
    private lateinit var firebaseHistoryRepository: FakeFirebaseHistoryRepository
    private lateinit var firebaseUserRepository: FakeFirebaseUserRepository
    private lateinit var firebaseAchievementRepository: FakeFirebaseAchievementRepository
    private lateinit var dispatcher: DispatcherProvider
    private lateinit var viewModel: BattleViewModel

    private val uid = "xxx"
    private val uid2 = "zzzz"

    val userData = UserData(null, uid, 1, 0, 0, 0, 20, 0, "PhotoUrl", "frameUrl", "TokenNotif")
    val userData2 = UserData(null, uid2, 1, 0, 0, 0, 30, 0, "PhotoUrl", "frameUrl", "TokenNotif")

    @Before
    fun setupViewModel() {

        roomUserRepository = FakeRoomUserRepository()
        roomAchievementRepository = FakeRoomAchievementRepository()
        firebaseAchievementRepository = FakeFirebaseAchievementRepository()
        firebaseUserRepository = FakeFirebaseUserRepository()
        firebaseHistoryRepository = FakeFirebaseHistoryRepository()
        dispatcher = coroutineRule

        val userAchievementData1 = UserAchievementData(
            1, 1,
            uid, 0, "unclaimed"
        )

        val userAchievementData2 = UserAchievementData(
            1, 2,
            uid, 0, "unclaimed"
        )

        val userAchievementData3 = UserAchievementData(
            1, 3,
            uid, 0, "unclaimed"
        )

        val userAchievementData4 = UserAchievementData(
            1, 4,
            uid, 0, "unclaimed"
        )

        val userAchievementData5 = UserAchievementData(
            1, 5,
            uid, 0, "unclaimed"
        )

        (roomAchievementRepository as FakeRoomAchievementRepository).addAchievements(
            userAchievementData1,
            userAchievementData2,
            userAchievementData3,
            userAchievementData4,
            userAchievementData5
        )
        (firebaseAchievementRepository as FakeFirebaseAchievementRepository).addData(
            userAchievementData1,
            userAchievementData2,
            userAchievementData3,
            userAchievementData4,
            userAchievementData5
        )

        (roomUserRepository as FakeRoomUserRepository).addUserData(userData)
        (firebaseUserRepository as FakeFirebaseUserRepository).addUsersData(userData)

        (roomUserRepository as FakeRoomUserRepository).setUserUid(uid)
        (firebaseUserRepository as FakeFirebaseUserRepository).setUserUid(uid)

        (roomAchievementRepository as FakeRoomAchievementRepository).setUserUid(uid)
        (firebaseAchievementRepository as FakeFirebaseAchievementRepository).setUserUid(uid)

        viewModel = BattleViewModel(
            roomUserRepository,
            roomAchievementRepository,
            firebaseHistoryRepository,
            firebaseUserRepository,
            firebaseAchievementRepository,
            dispatcher
        )

        InstantRuleExecution.start()
        TrampolineSchedulerRx.start()
    }

    @After
    fun cleanUp() {
        InstantRuleExecution.tearDown()
        TrampolineSchedulerRx.tearDown()
    }

    @Test
    fun getUserDataFromRoom_success(){
        //when
        viewModel.getUserDataFromRoom()
        //observer userLiveData
        val userLiveData = viewModel.userLiveData.getOrAwaitValue()
        //check if userLiveData equals to data from roomUserRepository
        assertThat(userLiveData, `is`(roomUserRepository.userServiceData[uid]))
    }

    @Test
    fun getUserDataFromRoom_error(){
        //set scenario
        roomUserRepository.setError(true)
        //when
        viewModel.getUserDataFromRoom()
        //observer userLiveData
        val errorLiveData = viewModel.errorLiveData.getOrAwaitValue()
        //check if userLiveData equals to data from roomUserRepository
        assertThat(errorLiveData, `is`("Error"))
    }

    @Test
    fun addHistoryToFirebase_success(){

    }

}