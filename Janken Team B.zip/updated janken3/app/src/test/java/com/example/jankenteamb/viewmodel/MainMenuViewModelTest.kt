package com.example.jankenteamb.viewmodel

import com.example.jankenteamb.helper.InstantRuleExecution
import com.example.jankenteamb.helper.MainCoroutineRule
import com.example.jankenteamb.helper.TrampolineSchedulerRx
import com.example.jankenteamb.helper.getOrAwaitValue
import com.example.jankenteamb.model.room.user.UserAchievementData
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.repository.firebase.FakeFirebaseStorageRepository
import com.example.jankenteamb.repository.room.FakeRoomAchievementRepository
import com.example.jankenteamb.repository.room.FakeRoomUserRepository
import com.google.firebase.auth.FirebaseAuth
import com.nhaarman.mockito_kotlin.mock
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@ExperimentalCoroutinesApi
class MainMenuViewModelTest(){
    @get:Rule
    val coroutineRule = MainCoroutineRule()

    private lateinit var viewModel: MainMenuViewModel
    private lateinit var roomUserRepository: FakeRoomUserRepository
    private lateinit var roomAchievementRepository: FakeRoomAchievementRepository
    private lateinit var firebaseStorageRepository: FakeFirebaseStorageRepository
    private lateinit var auth: FirebaseAuth

    private val uid = "xxx"
    private val uid2 = "zzzz"

    val userData = UserData(null, uid, 1, 0, 0, 0, 20, 0, "PhotoUrl", "frameUrl", "TokenNotif")
    val userData2 = UserData(null, uid2, 1, 0, 0, 0, 30, 0, "PhotoUrl", "frameUrl", "TokenNotif")


    @Before
    fun setupViewModel() {

        roomUserRepository = FakeRoomUserRepository()
        roomAchievementRepository = FakeRoomAchievementRepository()
        firebaseStorageRepository = FakeFirebaseStorageRepository()
        auth = mock<FirebaseAuth>()

        val userAchievementData1 = UserAchievementData(
            1, 1,
            uid, 0, "unclaimed"
        )

        val userAchievementData2 = UserAchievementData(
            1, 2,
            uid, 0, "unclaimed"
        )

        val userAchievementData3 = UserAchievementData(
            1, 3,
            uid, 0, "unclaimed"
        )

        val userAchievementData4 = UserAchievementData(
            1, 4,
            uid, 0, "unclaimed"
        )

        val userAchievementData5 = UserAchievementData(
            1, 5,
            uid, 0, "unclaimed"
        )

        roomAchievementRepository.addAchievements(
            userAchievementData1,
            userAchievementData2,
            userAchievementData3,
            userAchievementData4,
            userAchievementData5
        )

        roomUserRepository.addUserData(userData)
        roomUserRepository.setUserUid(uid)

        roomAchievementRepository.setUserUid(uid)

        viewModel = MainMenuViewModel(
            auth, roomUserRepository, firebaseStorageRepository, roomAchievementRepository, dispatcher = coroutineRule
        )


        InstantRuleExecution.start()
        TrampolineSchedulerRx.start()
    }

    @After
    fun cleanUp() {
        InstantRuleExecution.tearDown()
        TrampolineSchedulerRx.tearDown()
    }

    @Test
    fun getUserDataFromRoom_success() = coroutineRule.runBlockingTest{
        //run getUserDataFromRoom
        viewModel.getUserDataFromRoom()

        //observer userLiveData
        val userLiveData = viewModel.userLiveData.getOrAwaitValue()

        //check if userLiveData = userData from roomUserRepository
        assertThat(userLiveData, `is`(roomUserRepository.userServiceData[uid]))
//        assertThat(roomUserRepository.userServiceData.size, `is`(0))
    }

    @Test
    fun getUserDataFromRoom_error() = coroutineRule.runBlockingTest {
        //set scenario to error
        roomUserRepository.setError(true)

        //run getUserDataFromRoom
        viewModel.getUserDataFromRoom()

        //observer userLiveData
        val errorLiveData = viewModel.errorLiveData.getOrAwaitValue()

        //check if userLiveData = userData
        assertThat(errorLiveData, `is`("Error"))
    }

    @Test
    fun deleteUserData_success() = coroutineRule.runBlockingTest{
        //delete user data
        viewModel.deleteUserData()
        //check if userData has been deleted
        assertThat(roomUserRepository.userServiceData.size, `is`(0))
    }

    @Test
    fun deleteUserData_error() = coroutineRule.runBlockingTest{
        //set scenario to error
        roomUserRepository.setError(true)

        //delete user data
        viewModel.deleteUserData()

        //observe errorLiveData
        val error = viewModel.errorLiveData.getOrAwaitValue()

        //check userData still not deleted
        assertThat(error, `is`("Error"))
        assertThat(roomUserRepository.userServiceData.size, `is`(1))
    }

    @Test
    fun deleteAchievementData_success(){
        //deleteAchievementData
        viewModel.deleteAchievementData()

        //check if achievementData has been deleted
        assertThat(roomAchievementRepository.achievementServiceData.size, `is`(0))
    }

    @Test
    fun deleteAchievementData_error(){
        //set scenario to error
        roomAchievementRepository.serError(true)

        //deleteAchievementData
        viewModel.deleteAchievementData()

        //observe errorLiveData
        val error = viewModel.errorLiveData.getOrAwaitValue()

        //check achievementData still not deleted
        assertThat(error, `is`("Error"))
        assertThat(roomAchievementRepository.achievementServiceData.size, `is`(5))
    }

}