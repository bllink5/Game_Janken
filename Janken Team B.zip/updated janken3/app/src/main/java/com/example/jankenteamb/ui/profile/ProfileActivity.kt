package com.example.jankenteamb.ui.profile


import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.jankenteamb.R
import com.example.jankenteamb.adapter.ExperienceAdapter
import com.example.jankenteamb.model.firestore.GameHistoryFirestoreData
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.viewmodel.ProfileViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_profile.*
import kotlinx.android.synthetic.main.dialog_edit_profile.view.*
import org.koin.android.ext.android.inject

class ProfileActivity : AppCompatActivity() {
    lateinit var auth: FirebaseAuth
    private lateinit var historyAdapter : ExperienceAdapter
    private lateinit var profileViewModel: ProfileViewModel
    private val factory by inject<ProfileViewModel.Factory>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        auth = FirebaseAuth.getInstance()
        historyAdapter = ExperienceAdapter()

        profileViewModel = ViewModelProvider(
            this,
            factory).get(ProfileViewModel::class.java)

        profileViewModel.userLiveData.observe(this, onSuccessGetUserData)
        profileViewModel.errorLiveData.observe(this, onError)
        profileViewModel.successLiveData.observe(this, onSuccess)
        profileViewModel.historyLiveData.observe(this, onSuccessGetHistory)
        profileViewModel.frameUriLiveData.observe(this, onSuccessDownloadFrame)
        profileViewModel.photoUriLiveData.observe(this, onSuccessDownloadPhoto)
        profileViewModel.usernameUpdateLiveData.observe(this, onSuccessUpdateUsername)

        profileViewModel.getUserDataFromRoom()
        profileViewModel.getHistoryFromFirebase()

        rv_experience_log.layoutManager = LinearLayoutManager(this)
        rv_experience_log.adapter = historyAdapter

        iv_profile_picture.setOnClickListener {
            startActivity(Intent(this, UploadFotoGunakanFrameActivity::class.java))
        }

        tv_username_label.setOnClickListener {
            showEditDialog(tv_username_label.text.toString())
        }

        btn_back.setOnClickListener {
            onBackPressed()
        }

    }

    private fun showEditDialog(username: String) {
        this.let {
            val builder = AlertDialog.Builder(this)
            val inflateView =
                this.layoutInflater.inflate(R.layout.dialog_edit_profile, cl_profile_activity, false)
            builder.setView(inflateView)
            inflateView.et_edit_username.setText(username)
            val dialog = builder.create()
            dialog.show()

            inflateView.btn_cancel.setOnClickListener {
                dialog.cancel()
            }

            inflateView.btn_update.setOnClickListener {
                profileViewModel.updateUsername(inflateView.et_edit_username.text.toString())
                dialog.cancel()
            }
        }
    }


    private val onSuccessUpdateUsername = Observer<String> { username ->
        tv_username_label.text = username
    }


    val onError = Observer<String> {
        Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
    }

    val onSuccess = Observer<String> {
        Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
    }


    private val onSuccessGetHistory = Observer<List<GameHistoryFirestoreData>> { historyList ->
        if (historyList.isEmpty()){
            tv_experience_title.visibility = View.INVISIBLE
            rv_experience_log.visibility = View.INVISIBLE
        }else {
            historyAdapter.addData(historyList)
        }
    }


    private val onSuccessGetUserData = Observer<UserData> { userData ->
        tv_win.text = userData.win.toString()
        tv_lose.text = userData.lose.toString()
        tv_draw.text = userData.draw.toString()
        tv_level_status.text = userData.level.toString()
        tv_email_label.text = auth.currentUser?.email
        tv_username_label.text = auth.currentUser?.displayName
        pb_xp_status.progress = userData.exp
        pb_xp_status.max = when (userData.level) {
            1 -> 5
            2 -> 10
            3 -> 15
            4 -> 25
            5 -> 40
            else -> userData.exp
            }
        profileViewModel.downloadPhotoProfile()
        if (userData.frameUrl != ""){
            profileViewModel.downloadFrameProfile(userData.frameUrl)
        }
    }

    private val onSuccessDownloadFrame = Observer<Uri> { uri ->
        Glide.with(baseContext)
            .load(uri)
            .apply(RequestOptions().circleCrop())
            .into(iv_frame_profile)
    }

    private val onSuccessDownloadPhoto = Observer<Uri> { uri ->
        Glide.with(baseContext)
            .load(uri)
            .apply(RequestOptions().circleCrop())
            .into(iv_profile_picture)
    }



}