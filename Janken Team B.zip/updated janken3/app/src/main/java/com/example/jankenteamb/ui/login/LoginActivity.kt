package com.example.jankenteamb.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.jankenteamb.R
import com.example.jankenteamb.ui.menu.MenuActivity
import com.example.jankenteamb.ui.register.RegisterActivity
import com.example.jankenteamb.viewmodel.LoginViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*
import org.koin.android.ext.android.inject

//view dihilangkan
class LoginActivity : AppCompatActivity() {
    lateinit var auth: FirebaseAuth

//    private val presenter by inject<LoginPresenter>()

    //menggantikan presenter
    private val factory by inject<LoginViewModel.Factory>()
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //inisialisasi ViewModel
        loginViewModel = ViewModelProvider(
            this,
            factory
        ).get(LoginViewModel::class.java)

        //INISIALISASI SEMUA OBSERVER
        //untuk toast error
        loginViewModel.errorLiveData.observe(this, onError)
        //untuk toast success
        loginViewModel.successLiveData.observe(this, onSuccess)

//        presenter.setView(this)
//        presenter.setAuth(FirebaseAuth.getInstance())
        btn_login.setOnClickListener {
            //tidak digunakan lagi, digantikan viewModel
//            presenter.loginToFirebase(
//                et_email_login.text.toString(),
//                et_password_login.text.toString()
//            )
            //menggantikan presenter.loginToFirebase di atas
            loginViewModel.loginToFirebase(
                et_email_login.text.toString(),
                et_password_login.text.toString()
            )
        }

        tv_move_register.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    //tidak perlu karena disposablenya sudah ditangani di ViewModel
//    override fun onDestroy() {
//        super.onDestroy()
//        presenter.clearAllDisposable()
//    }

    //tidak digunakan lagi
//    override fun onError(msg: String) {
//        runOnUiThread {
//            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
//        }
//    }
    //menggantikan onError di atas
    val onError = Observer<String> {
        runOnUiThread {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
        }
    }

    //tidak digunakan lagi
//    override fun onSuccess(msg: String) {
//        runOnUiThread {
//            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
//            val intent = Intent(this, MenuActivity::class.java)
//            startActivity(intent)
//        }
//    }
    //menggantikan onSucces di atas
    val onSuccess = Observer<String> {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
    }

}