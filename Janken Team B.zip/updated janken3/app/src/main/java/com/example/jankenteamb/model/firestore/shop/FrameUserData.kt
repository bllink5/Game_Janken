package com.example.jankenteamb.model.firestore.shop

data class FrameUserData (
    var frameUrl : String = "",
    var title : String = ""
)