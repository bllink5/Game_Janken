package com.example.jankenteamb.utils

import android.net.Uri
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.DisposableHandle
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.net.URI


class FirebaseHelper(private val auth: FirebaseAuth, private val mStorageRef : StorageReference ) {

    fun isFirebaseLogin(): Boolean {
        return auth.currentUser != null
    }

    fun signoutFirebase() {
        auth.signOut()
    }

    fun getUsername(): String {
        return auth.currentUser?.displayName!!
    }

    fun getProfilePhotoUri(): Uri {
        return auth.currentUser?.photoUrl!!
    }





}