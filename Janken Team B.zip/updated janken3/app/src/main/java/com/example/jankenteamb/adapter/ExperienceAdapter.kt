package com.example.jankenteamb.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.jankenteamb.R
import com.example.jankenteamb.model.firestore.GameHistoryFirestoreData
import kotlinx.android.synthetic.main.item_player_experience.view.*

class ExperienceAdapter : RecyclerView.Adapter<ExperienceAdapter.ViewHolder>() {
    private var listHistory = mutableListOf<GameHistoryFirestoreData>()

    fun addData(listHistory: List<GameHistoryFirestoreData>){
        this.listHistory.clear()
        this.listHistory.addAll(listHistory)
        notifyDataSetChanged()
    }

    inner class ViewHolder(val view: View) : RecyclerView.ViewHolder(view){
        fun bind(history : GameHistoryFirestoreData){
            view.tv_result.text = history.gameResult
            view.tv_xp.text = when(history.gameResult){
                "Player Win" -> "+5 xp"
                "Player Lose" -> "+0 xp"
                else -> "+3 xp"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExperienceAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_player_experience, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = listHistory.size

    override fun onBindViewHolder(holder: ExperienceAdapter.ViewHolder, position: Int) {
        holder.bind(listHistory[position])
    }

}