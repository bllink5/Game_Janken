package com.example.jankenteamb.model.room.query

data class PointData (
    val point:Int
)