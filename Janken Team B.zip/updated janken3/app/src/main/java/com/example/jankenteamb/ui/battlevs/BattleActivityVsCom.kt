package com.example.jankenteamb.ui.battlevs

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.jankenteamb.R
import com.example.jankenteamb.model.room.user.UserData
import com.example.jankenteamb.viewmodel.BattleViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_battle_vs_com.*
import kotlinx.android.synthetic.main.activity_battle_vs_com.btn_back
import kotlinx.android.synthetic.main.activity_battle_vs_com.tv_draw_multi
import org.koin.android.ext.android.inject

//view dihilangkan
class BattleActivityVsCom : AppCompatActivity() {
    var pickPlayer = ""
    var pickComputer = ""
    var view1: View? = null
    var view2: View? = null
    var state1 = true
    var computer = mutableListOf("rock", "paper", "scissor")
    var tag = ""
    private lateinit var listPlayer1: MutableList<ImageView>
    private lateinit var auth: FirebaseAuth

    //menggantikan presenter
    private val factory by inject<BattleViewModel.Factory>()
    private lateinit var battleViewModel: BattleViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_battle_vs_com)
        auth = FirebaseAuth.getInstance()
        //Inisialisasi viewModel
        battleViewModel = ViewModelProvider(
            this,
            factory
        ).get(BattleViewModel::class.java)

        //INISIALISASI SEMUA OBSERVER
        //untuk meng-observe userLiveData jika ada perubahan data
        battleViewModel.userLiveData.observe(this, userLiveData)

        //mengobserve historyResult dan memasukkan data history dan mengupdate data user
        // ke firebase jika ada perubahan, fungsi ini sebelumnya ada di dalam updateUserData
        // di BattlePresenter
        battleViewModel.historyResult.observe(this, Observer {
            battleViewModel.addHistoryToFirebase("Single Player", it)
        })

        //mengobserve battleResult jika ada perubahan, maka tv_result akan diubah
        //sesuai dengan hasil battleResult
        battleViewModel.battleResult.observe(this, showResult)

        battleViewModel.errorLiveData.observe(this, onError)

        //        profilePresenter.setView(this)
//                profilePresenter.getUserDataFromRoom("battle")

        //mengantikan profilePresenter.getUserDataFromRoom("battle") di atas
        battleViewModel.getUserDataFromRoom()

        listPlayer1 = mutableListOf(iv_rock_one, iv_paper_one, iv_scissor_one)

        btn_back.setOnClickListener {
            onBackPressed()
        }

        listPlayer1.forEach {
            it.setOnClickListener {
                if (state1) {
                    it.background = getDrawable(R.drawable.bg_battle_pick)
                    pickPlayer = it.contentDescription.toString()
                    pickComputer = computer.random()
                    if (pickComputer == "paper") {
                        iv_paper_two.background = getDrawable(R.drawable.bg_battle_pick)
                        view2 = iv_paper_two
                    } else if (pickComputer == "rock") {
                        iv_rock_two.background = getDrawable(R.drawable.bg_battle_pick)
                        view2 = iv_rock_two
                    } else {
                        iv_scissor_two.background = getDrawable(R.drawable.bg_battle_pick)
                        view2 = iv_scissor_two
                    }

//                    result.theResult(
//                        tv_username_one.text.toString(),
//                        tv_username_two.text.toString(),
//                        pickPlayer,
//                        pickComputer,
//                        "Single Player"
//                    )
                    //mengantikan result.theResult di atas
                    battleViewModel.getResult(
                        tv_username_one.text.toString(),
                        tv_username_two.text.toString(),
                        pickPlayer,
                        pickComputer
                    )

                    view1 = it
                    state1 = false
                    Log.d(tag, "Pemain choose $pickPlayer")
                    Log.d(tag, "Computer choose $pickComputer")
                } else {
                    Toast.makeText(this, "Refresh", Toast.LENGTH_SHORT).show()
                }
            }
        }


        btn_reset.setOnClickListener {
            pickPlayer = ""
            pickComputer = ""
            resetBackground(view1, view2)
            state1 = true
            tv_result.text = "VS"
            Log.d(tag, "RESET")
        }
    }

    private fun resetBackground(view1: View?, view2: View?) {
        view1?.background = getDrawable(android.R.color.transparent)
        view2?.background = getDrawable(android.R.color.transparent)
    }

    //tidak akan digunakan lagi, digantikan dengan Observer di bawah
//    override fun showResult(result: String) {
//        tv_result.text = result
//    }
    //untuk merubah tv_result menggantikan fun showResult di atas
    val showResult = Observer<String> { result ->
        runOnUiThread {
            tv_result.text = result
        }
    }

    //Tidak digunakan lagi, diganti onError dibawah
//    override fun onError(msg: String) {
//        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
//    }
    //menggantikan fun onError
    val onError = Observer<String> {
        runOnUiThread {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
        }
    }

    //tidak akan digunakan lagi di viewModel digantikan dengan observer dibawah
//    override fun onSuccessOnBattle(userData: UserData) {
//        runOnUiThread {
//            tv_draw_multi.text = userData.draw.toString()
//            tv_win.text = userData.win.toString()
//            tv_lose.text = userData.lose.toString()
//        }
//    }

    //mengantikan fungsi onSuccessOnBattle di atas
    val userLiveData = Observer<UserData> { userData ->
        runOnUiThread {
            tv_username_one.text = auth.currentUser?.displayName!!
            tv_draw_multi.text = userData.draw.toString()
            tv_win.text = userData.win.toString()
            tv_lose.text = userData.lose.toString()
        }
    }


}
