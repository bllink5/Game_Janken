package com.example.jankenteamb.ui.menu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.jankenteamb.R
import com.example.jankenteamb.ui.menu.history.MenuHistoryFragment
import com.example.jankenteamb.ui.menu.friend.FriendFragment
import com.example.jankenteamb.ui.menu.mainMenu.MainMenuFragment
import com.example.jankenteamb.ui.menu.shop.ShopFragment
import kotlinx.android.synthetic.main.activity_menu.*

class MenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        supportFragmentManager.beginTransaction().apply {
            replace(
                R.id.layout_container,
                MainMenuFragment()
            )
            commit()
        }


        bottom_navigation.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.main_menu -> {
                    navigateFragment(MainMenuFragment())
                    supportActionBar?.title = "Main"
                }
                R.id.history_menu -> {
                    navigateFragment(MenuHistoryFragment())
                    supportActionBar?.title = "History"
                }
                R.id.shop_menu -> {
                    navigateFragment(ShopFragment())
                    supportActionBar?.title = "Shop"
                }
                R.id.friend_menu -> {
                    navigateFragment(FriendFragment())
                    supportActionBar?.title = "Friend"
                }
            }
            true
        }
    }

    private fun navigateFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.layout_container, fragment)
            commit()
        }
    }
}