package com.example.jankenteamb.model.firestore.friendlist

data class FriendListData(
    var photoUrl: String = "",
    var username: String = "",
    var uid: String = ""
)