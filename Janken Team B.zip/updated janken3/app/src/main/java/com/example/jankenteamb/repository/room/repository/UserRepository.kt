package com.example.jankenteamb.repository.room.repository

import com.example.jankenteamb.api.observer.ApiCompletableObserver
import com.example.jankenteamb.api.observer.ApiObserver
import com.example.jankenteamb.api.observer.ApiSingleObserver
import com.example.jankenteamb.model.room.query.PointData
import com.example.jankenteamb.model.room.user.UserData
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

interface UserRepository {
    fun insertUserData(userData: UserData, onResult: () -> Unit, onError: (Throwable) -> Unit)

    fun getUserPointDataByUid(onResult: (Int) -> Unit, onError: (Throwable) -> Unit)

    fun updateUserPointByUid(
        newPoint: Int,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    )

    fun getUserDataByUid(onResult: (UserData) -> Unit, onError: (Throwable) -> Unit)

    fun getObservableUserData(onResult: (UserData) -> Unit, onError: (Throwable) -> Unit)
    fun updateUserData(
        level: Int,
        win: Int,
        draw: Int,
        lose: Int,
        exp: Int,
        onResult: () -> Unit,
        onError: (Throwable) -> Unit
    )

    fun updateUserFrame(frameUrl: String, onResult: () -> Unit, onError: (Throwable) -> Unit)

    fun deleteUserData(userData: UserData)
    fun onDestroy()
}