package com.example.jankenteamb.repository.firebase.repository

import com.example.jankenteamb.model.RepositoryResult
import com.example.jankenteamb.model.firestore.GameHistoryFirestoreData
import io.reactivex.Single

interface HistoryRepository {
    suspend fun addHistory(history: GameHistoryFirestoreData): RepositoryResult<String>

    suspend fun getHistoryFromFirebase(): RepositoryResult<List<GameHistoryFirestoreData>>
}