package com.example.jankenteamb.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.jankenteamb.repository.firebase.FirebaseStorageRepository
import com.example.jankenteamb.repository.firebase.repository.StorageRepository
import com.example.jankenteamb.utils.DispatcherProvider
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.storage.UploadTask
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegisterViewModel(
    private val auth: FirebaseAuth,
    private val firebaseStorageRepository: StorageRepository,
    private val dispatcher: DispatcherProvider
) : ViewModel() {
    private val _errorLiveData = MutableLiveData<String>()
    val errorLiveData: LiveData<String> get() = _errorLiveData

    private val _successLiveData = MutableLiveData<String>()
    val successLiveData: LiveData<String> get() = _successLiveData

    fun registerToFirebase(email: String, password: String, username: String, uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task: Task<AuthResult> ->
                        task.addOnSuccessListener {
                            auth.currentUser?.let {
                                val profileUpdate = UserProfileChangeRequest.Builder()
                                    .setDisplayName(username)
                                    .build()
                                it.updateProfile(profileUpdate)
                            }
                            CoroutineScope(dispatcher.io()).launch {
                                firebaseStorageRepository.uploadPhotoProfile(
                                    auth.currentUser?.uid!!,
                                    uri, onResult = {
                                        _successLiveData.value =
                                            "Register berhasil $email $password ${auth.currentUser?.uid!!}"
                                    }
                                )
                            }

                        }
                        task.addOnFailureListener {
                            _errorLiveData.postValue(it.message)
                        }
                    }
            } catch (e: Exception) {
                _errorLiveData.postValue(e.message)
            }
        }
    }

    class Factory(
        private val auth: FirebaseAuth,
        private val firebaseStorageRepository: FirebaseStorageRepository,
        private val dispatcher: DispatcherProvider
    ) : ViewModelProvider.NewInstanceFactory() {
        override fun <T : ViewModel?> create(modelClass: Class<T>): T {
            return RegisterViewModel(auth, firebaseStorageRepository, dispatcher) as T
        }
    }
}