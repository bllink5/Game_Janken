package com.example.jankenteamb.ui.achivement

import org.junit.Assert.*

class AchivementActivityTest